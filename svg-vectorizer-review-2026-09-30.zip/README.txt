SVG Vectorizer 0.1.1
English README, real before/after demo and manual publication kit.
Start with review/REPORT.md and review/PUBLISHING-STEPS.md.
Plugin upload file: plugin/svg-vectorizer.zip (not this outer bundle).
