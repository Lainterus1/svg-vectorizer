# Publish SVG Vectorizer yourself

Prepared version: **0.1.1**. Nothing from this revised package has been uploaded to
OpenAI. The earlier standalone GitHub source is already public; the revised English
README and demonstration in this bundle are prepared locally for you to publish.

## 1. Update your standalone GitHub repository

Repository: https://github.com/Lainterus1/svg-vectorizer

The included `repo-update.patch` is based on commit
`1a4238130b59a410a9a3269f294e4146756caba7`. In a clean checkout of that repository:

```bash
git apply --check /path/to/repo-update.patch
git apply /path/to/repo-update.patch
git diff --check
```

Review and commit the changes, then push them when ready. If the check reports a
conflict, reconcile your later changes rather than forcing the patch. Alternatively,
extract the plugin ZIP into a separate folder and copy its reviewed files into the
repository without replacing `.git` or unrelated files.

The new README is compact English, with a real before/after image and links to a
separate technical reference. Demo files, their renderer and reproduction commands
are included. Privacy wording is translated faithfully into English, including the
approved 30-day/earlier-on-request support retention rule.

## 2. Complete the publisher prerequisite

Open https://platform.openai.com/plugins and select **Personal**.
The portal currently requires a verified developer identity before it permits a ZIP
upload. Under Organization settings → General → Verifications, use **Individual**
and complete the identity process yourself. Review any legal terms or identity-document
request directly; this package does not complete verification for you.

The name displayed in the directory comes from the selected verified identity. The
package uses **Daniil**, but that field alone does not override the portal identity.

## 3. Upload the correct ZIP

Upload the nested **plugin/svg-vectorizer.zip** from this bundle, not the whole
review bundle and not GitHub's source archive. The plugin ZIP has its manifest,
skills, scripts and assets at its root.

In Metadata & Skills, resolve any actual portal findings and re-upload a corrected
ZIP if needed. The published privacy URL should be:
https://github.com/Lainterus1/svg-vectorizer/blob/main/docs/PRIVACY.md

Publisher: Daniil. Support: gonchardaniil1998@gmail.com. No MCP, remote service,
API key or MCP review cases are needed for this skills-only plugin.

## 4. Review, then publish

Test installation and skill invocation in the ChatGPT/Codex clients you intend to
support. The local CLI tests do not prove host/client compatibility. Submit the
checked package for review. After approval, use the portal's separate publish action.
Do not claim an OpenAI listing until the portal confirms it.

Official guide: https://developers.openai.com/plugins/deploy/submission
